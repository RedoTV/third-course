package lab3.task3_2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //это писал не я
        Subscription subscription = new Subscription();
        // System.out.println(subscription.getClient().getFullname().length());
        subscription.fillFromConsole(scanner);
        subscription.output();
        // System.out.println(subscription.toString());



        scanner.close();
    }
}
