package lab3.task3_2;

import java.util.Scanner;

public class Client extends Person {
    private String address;

    public Client(String fullname, String phone, String address) {
        super(fullname, phone);
        this.address = address;
    }

    public Client() {
        super();
        this.address = "";
    }
    
    @Override
    public String getRoleDescription() {
        return "Клиент";
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public void fillFromConsole(Scanner scanner) {
        System.out.print("Введите ФИО клиента: ");
        this.fullName = scanner.nextLine();
        System.out.print("Введите телефон клиента: ");
        this.phone = scanner.nextLine();
        System.out.print("Введите адрес клиента: ");
        this.address = scanner.nextLine();
    }

    @Override
    public String toString() {
        return "Client { " +
                "fullName='" + fullName + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                " }";
    }
}
