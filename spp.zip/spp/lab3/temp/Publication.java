package lab3.task3_2;

import java.util.Scanner;

public class Publication implements IDataObject {
    private String title;
    private double price;
    private PublicationTypeEnum publicationType;

    public Publication(String title, double price, PublicationTypeEnum publicationType) {
        this.title = title;
        this.price = price;
        this.publicationType = publicationType;
    }

    public Publication() {
        this.title = "";
        this.price = 0.0;
        this.publicationType = PublicationTypeEnum.NEWSPAPER;
    }

    @Override
    public void fillFromConsole(Scanner scanner) {
        System.out.println("Выберите тип издания:");
        for (PublicationTypeEnum type : PublicationTypeEnum.values()) {
            System.out.println((type.ordinal() + 1) + ". " + type.getDisplayName());
        }
        System.out.print("Ваш выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();
        this.publicationType = PublicationTypeEnum.values()[choice - 1];

        System.out.print("Введите название издания: ");
        this.title = scanner.nextLine();
        
        System.out.print("Введите цену: ");
        this.price = scanner.nextDouble();
        scanner.nextLine();
    }

    @Override
    public void output() {
        System.out.println(this);
    }
    
    public void setTitle(String title) { 
        this.title = title; 
    }

    public void setPrice(double price) { 
        this.price = price; 
    }

    public void setPublicationType(PublicationTypeEnum publicationType) { 
        this.publicationType = publicationType; 
    }

    public String getTitle() { 
        return title; 
    }

    public double getPrice() { 
        return price; 
    }

    public PublicationTypeEnum getPublicationType() { 
        return publicationType; 
    }

    @Override
    public String toString() {
        return "Publication { " +
                "title='" + title + "', price=" + price + ", " +
                "publicationType=" + publicationType.getDisplayName() +
                " }";
    }
}