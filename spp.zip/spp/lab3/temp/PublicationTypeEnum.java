package lab3.task3_2;

public enum PublicationTypeEnum {
    NEWSPAPER("Газета"),
    MAGAZINE("Журнал"),
    BOOK("Книга");

    private final String displayName;

    PublicationTypeEnum(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}