package lab3.task3_2;

public abstract class Person implements IDataObject {
    protected String fullName;
    protected String phone;

    public Person(String fullName, String phone) {
        this.fullName = fullName;
        this.phone = phone;
    }

    public Person() {
        this.fullName = "";
        this.phone = "";
    }

    public abstract String getRoleDescription();

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}