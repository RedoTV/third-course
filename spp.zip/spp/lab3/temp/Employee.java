package lab3.task3_2;

import java.util.Scanner;

public class Employee extends Person {
    private String jobTitle;

    public Employee(String fullName, String phone, String jobTitle) {
        super(fullName, phone);
        this.jobTitle = jobTitle;
    }

    public Employee() {
        super();
        this.jobTitle = "";
    }
    
    @Override
    public String getRoleDescription() {
        return "Сотрудник";
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    @Override
    public void fillFromConsole(Scanner scanner) {
        System.out.print("Введите ФИО сотрудника: ");
        this.fullName = scanner.nextLine();
        System.out.print("Введите телефон сотрудника: ");
        this.phone = scanner.nextLine();
        System.out.print("Введите должность сотрудника: ");
        this.jobTitle = scanner.nextLine();
    }

    @Override
    public String toString() {
        return "Employee { " +
                "fullName='" + fullName + '\'' +
                ", phone='" + phone + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                " }";
    }
}
