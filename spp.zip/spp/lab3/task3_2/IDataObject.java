package lab3.task3_2;

import java.util.Scanner;

public interface IDataObject {

    void fillFromConsole(Scanner scanner);
    default void output() {
        System.out.println(this);
    }
}